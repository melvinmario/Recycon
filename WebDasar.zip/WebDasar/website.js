function myFunction() 
{
    document.getElementById("myDropdown").classList.toggle("show") ;
}
  
window.onclick = function(event) 
{
  if (!event.target.matches('.dropbutton')) 
  {
    var favorites = document.getElementsByClassName("dropdowncontent") ;
    var i;
    for (i = 0; i < favorites.length; i++) 
    {
      var favoriteList = favorites[i] ;
      if (favoriteList.classList.contains('show')) 
      {
        favoriteList.classList.remove('show') ;
      }
    }
  }
}

const hamburger = document.querySelector(".hamburger");
const navMenu = document.querySelector(".menucontent");

hamburger.addEventListener("click", mobileMenu);

function mobileMenu() {
    hamburger.classList.toggle("active");
    navMenu.classList.toggle("active");
}

const navLink = document.querySelectorAll(".menucontent a");

navLink.forEach(n => n.addEventListener("click", closeMenu));

function closeMenu() {
    hamburger.classList.remove("active");
    navMenu.classList.remove("active");
}